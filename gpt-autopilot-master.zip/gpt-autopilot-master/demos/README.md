## GPT-AutoPilot Demos

This folder contains demos of projects created with GPT-AutoPilot. Every folder is its own project and includes all the project files plus a `prompt.txt` file that includes the prompt(s) given to the program in order to create the project.

Feel free to add your own projects here, but make sure to include the `prompt.txt` with the exact input/output of the script.
