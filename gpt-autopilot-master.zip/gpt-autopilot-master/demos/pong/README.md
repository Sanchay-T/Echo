# Pong Game

This is the classic Pong game implemented in C using Raylib.

## Compiling and running the game

1. Ensure you have GCC and Raylib installed on your system.
2. Run `chmod +x build.sh` to make the build script executable.
3. Run `./build.sh` to compile the game.
4. Run `./pong` to start the game.
