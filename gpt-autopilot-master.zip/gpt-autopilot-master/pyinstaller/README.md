# GPT-AutoPilot PyInstaller

GPT-AutoPilot can be converted into a standalone application with [PyInstaller](https://www.pyinstaller.org/).

This folder has scripts for creating a zip package of the standalone application for different operating systems.

The standalone application will be created for the platform the script is run on.
