# Tests for GPT-AutoPilot

This folder includes some tests that are used to check that the program still works properly after changes. Currently tests are only partly automated. The `run_tests.py` will run all tests in this folder and put the results to a folder called `results`. Tests **should** run automatically but the results must be inspected manually at the moment.
