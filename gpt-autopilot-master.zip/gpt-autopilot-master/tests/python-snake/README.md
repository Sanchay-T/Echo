# Test: Python Snake Game

The expected result is a GUI snake game in Python, with arrow key controls.
