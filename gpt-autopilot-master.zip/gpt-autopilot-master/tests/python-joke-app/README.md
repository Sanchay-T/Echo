# Test: Python Flask Joke App

The expected result is a web application that has a big red button that says "Tell a joke" and when you click it, a random joke appears below it.
